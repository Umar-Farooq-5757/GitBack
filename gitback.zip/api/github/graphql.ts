import type { VercelRequest, VercelResponse } from "@vercel/node";
import { graphqlRequest } from "../_lib/graphql";
import { success, failure } from "../_lib/response";
import { REPOSITORY_QUERY } from "../_lib/queries";

export default async function handler(
  req: VercelRequest,
  res: VercelResponse,
) {
  try {
    const {
      owner,
      repo,
    } = req.query;
    console.log("Owner:", owner);
console.log("Repo:", repo);
    if (
      !owner ||
      !repo ||
      typeof owner !== "string" ||
      typeof repo !== "string"
    ) {
      return failure(
        res,
        "Missing owner or repo.",
        400,
      );
    }

    const data = await graphqlRequest<any>(
    REPOSITORY_QUERY,
    { owner, repo }
);
console.log("GRAPHQL DATA");
console.log(JSON.stringify(data, null, 2));

const repository = data.repository;

const response = {
    name: repository.name,
    fullName: repository.nameWithOwner,
    description: repository.description,
    homepage: repository.homepageUrl,

    owner: {
        login: repository.owner.login,
        avatar: repository.owner.avatarUrl,
    },

    stars: repository.stargazerCount,
    forks: repository.forkCount,
    watchers: repository.watchers.totalCount,

    issues: repository.openIssues.totalCount,
    pullRequests: repository.pullRequests.totalCount,
    discussions: repository.discussions.totalCount,

    createdAt: repository.createdAt,
    updatedAt: repository.updatedAt,
    pushedAt: repository.pushedAt,

    topics:
        repository.repositorysitoryTopics.nodes.map(
            (t:any)=>t.topic.name
        ),

    languages:
        repository.languages.edges.map((l:any)=>({

            name:l.node.name,
            color:l.node.color,
            size:l.size,

            percentage:
                Number(
                    (
                        l.size /
                        repository.languages.totalSize
                    )*100
                ).toFixed(2)

        })),

    branches:
        repository.refs.nodes.map((b:any)=>({

            name:b.name,
            sha:b.target?.oid,

            protected:
                !!b.branchProtectionRule

        })),

    releases:
        repository.releases.nodes.map((r:any)=>({

            tag:r.tagName,
            title:r.name,
            publishedAt:r.publishedAt,
            prerelease:r.isPrerelease,

            author:r.author?.login

        })),

    commits:
        repository.defaultBranchRef.target.history.nodes.map((c:any)=>({

            sha:c.oid,

            shortSha:c.abbreviatedOid,

            message:c.messageHeadline,

            author:
                c.author.user?.login ??
                c.author.name,

            avatar:
                c.author.avatarUrl,

            date:
                c.committedDate

        }))

};

return success(res,response);
  } catch (err) {
    return failure(
      res,
      err instanceof Error ? err.message : "Unknown error",
      500,
    );
  }
}
