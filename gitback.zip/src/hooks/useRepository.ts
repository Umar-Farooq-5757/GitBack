import { useEffect, useState } from "react";
import { getRepository } from "../api/github.ts";

export function useRepository(owner: string, repo: string) {
  const [data, setData] = useState<any>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      try {
        console.log("Loading...");

        const repository = await getRepository(owner, repo);

        console.log(repository);

        setData(repository);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [owner, repo]);

  return {
    data,
    loading,
    error,
  };
}
